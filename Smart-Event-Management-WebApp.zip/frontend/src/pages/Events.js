import axios from "axios";
import QRCode from "qrcode.react";

export default function Events() {
  const userId = "STUDENT001";
  const eventId = "PASTE_EVENT_ID_FROM_DB";

  const register = async () => {
    await axios.post("http://localhost:5000/api/events/register", {
      eventId,
      userId
    });
    alert("Registered Successfully");
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Smart Event</h2>
      <p>College Hackathon</p>

      <button onClick={register}>Register</button>

      <h3>Your QR Code</h3>
      <QRCode value={JSON.stringify({ eventId, userId })} />
    </div>
  );
}