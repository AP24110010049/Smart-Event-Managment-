import { QrReader } from "react-qr-reader";
import axios from "axios";

export default function QRScanner() {
  const handleScan = async (data) => {
    if (data) {
      const parsed = JSON.parse(data);
      await axios.post(
        "http://localhost:5000/api/events/attendance",
        parsed
      );
      alert("Attendance Marked");
    }
  };

  return (
    <div>
      <h3>QR Scanner</h3>
      <QrReader
        onResult={(result) => result && handleScan(result.text)}
        constraints={{ facingMode: "environment" }}
      />
    </div>
  );
}