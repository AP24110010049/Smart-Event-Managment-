import { useEffect, useState } from "react";
import axios from "axios";

export default function AdminDashboard() {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/events/analytics")
      .then(res => setData(res.data));
  }, []);

  return (
    <div style={{ padding: 20 }}>
      <h2>Admin Analytics</h2>
      {data.map((e, i) => (
        <div key={i}>
          <p><b>{e.title}</b></p>
          <p>Registrations: {e.registrations}</p>
          <p>Attendance: {e.attendance}</p>
        </div>
      ))}
    </div>
  );
}