import Events from "./pages/Events";
import AdminDashboard from "./pages/AdminDashboard";
import QRScanner from "./pages/QRScanner";

export default function App() {
  return (
    <>
      <Events />
      <AdminDashboard />
      <QRScanner />
    </>
  );
}