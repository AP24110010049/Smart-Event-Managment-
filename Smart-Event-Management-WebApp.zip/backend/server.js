const express = require("express");
require("./db");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/events", require("./routes/eventRoutes"));

app.listen(5000, () =>
  console.log("Backend running on http://localhost:5000")
);