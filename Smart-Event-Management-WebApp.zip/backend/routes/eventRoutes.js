const express = require("express");
const Event = require("../models/Event");
const router = express.Router();

router.post("/create", async (req, res) => {
  const event = await Event.create({
    ...req.body,
    registered: [],
    attendance: []
  });
  res.json(event);
});

router.get("/", async (req, res) => {
  res.json(await Event.find());
});

router.post("/register", async (req, res) => {
  const { eventId, userId } = req.body;
  const event = await Event.findById(eventId);

  if (!event.registered.includes(userId)) {
    event.registered.push(userId);
    await event.save();
  }
  res.json({ message: "Registered Successfully" });
});

router.post("/attendance", async (req, res) => {
  const { eventId, userId } = req.body;
  const event = await Event.findById(eventId);

  if (!event.attendance.includes(userId)) {
    event.attendance.push(userId);
    await event.save();
  }
  res.json({ message: "Attendance Marked" });
});

router.get("/analytics", async (req, res) => {
  const events = await Event.find();
  res.json(events.map(e => ({
    title: e.title,
    registrations: e.registered.length,
    attendance: e.attendance.length
  })));
});

module.exports = router;